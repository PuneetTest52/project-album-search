package com.test.albumsearch.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

import java.util.List;

import androidx.annotation.Nullable;

public class AlbumMatches {

    @SerializedName("album") List<Albums> mAlbums;

    @Nullable
    public List<Albums> getAlbumsList() {
        return mAlbums;
    }
}
