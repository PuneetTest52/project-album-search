package com.test.albumsearch.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

import androidx.annotation.Nullable;

public class AlbumResults {

    @SerializedName("albummatches") private AlbumMatches mAlbumMatches;

    @Nullable
    public AlbumMatches getAlbumMatches() {
        return mAlbumMatches;
    }
}
