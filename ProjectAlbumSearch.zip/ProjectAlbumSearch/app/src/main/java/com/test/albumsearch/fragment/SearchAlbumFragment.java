package com.test.albumsearch.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.test.albumsearch.R;
import com.test.albumsearch.dto.AlbumApiResponse;
import com.test.albumsearch.viewmodel.AlbumViewModel;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class SearchAlbumFragment extends Fragment {

    @Nullable private Unbinder mViewUnbinder;
    @BindView(R.id.tv_name) TextView mName;

    public static SearchAlbumFragment newInstance() {
        return new SearchAlbumFragment();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mViewUnbinder = ButterKnife.bind(this, view);
        AlbumViewModel model = ViewModelProviders.of(this).get(AlbumViewModel.class);
        model.getSearchedAlbum().observe(this, new Observer<AlbumApiResponse>() {
            @Override
            public void onChanged(AlbumApiResponse albumApiResponse) {
                mName.setText(albumApiResponse.getAlbumResults().getAlbumMatches().getAlbumsList().get(0).getName());
            }
        });
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_album_search_view, container, false);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        if (mViewUnbinder != null) {
            mViewUnbinder.unbind();
        }
    }
}
