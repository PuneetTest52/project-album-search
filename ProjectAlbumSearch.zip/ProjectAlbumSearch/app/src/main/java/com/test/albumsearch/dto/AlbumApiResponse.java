package com.test.albumsearch.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class AlbumApiResponse {

    @SerializedName("results") private AlbumResults mAlbumResults;

    @NonNull
    public AlbumResults getAlbumResults() {
        return mAlbumResults;
    }
}
