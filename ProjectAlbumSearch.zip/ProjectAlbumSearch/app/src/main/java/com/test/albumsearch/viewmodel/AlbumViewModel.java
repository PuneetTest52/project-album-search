package com.test.albumsearch.viewmodel;

import android.annotation.SuppressLint;
import android.util.Log;

import com.test.albumsearch.dto.AlbumApiResponse;
import com.test.albumsearch.network.AlbumApi;
import com.test.albumsearch.network.NetworkClient;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import retrofit2.Retrofit;

public class AlbumViewModel extends ViewModel {

    private MutableLiveData<AlbumApiResponse> mAlbumApiResponseData;

    @NonNull
    public LiveData<AlbumApiResponse> getSearchedAlbum() {
        if (mAlbumApiResponseData == null) {
            mAlbumApiResponseData = new MutableLiveData<AlbumApiResponse>();
            loadAlbum();
        }
        return mAlbumApiResponseData;
    }

    @SuppressLint("CheckResult")
    private void loadAlbum() {
        // Do an asynchronous operation to fetch users.

        Retrofit retrofit = NetworkClient.getRetrofitClient();
        AlbumApi albumApi = retrofit.create(AlbumApi.class);

        albumApi.getAlbumsResponse("album.search", "india")
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<AlbumApiResponse>() {
                    @Override
                    public void accept(AlbumApiResponse albumApiResponse) {
                        Log.d("##$$", albumApiResponse + "");
                        mAlbumApiResponseData.setValue(albumApiResponse);
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) {
                        Log.d("##$$", "");
                    }
                });
    }
}
