package com.test.albumsearch.network;

import com.test.albumsearch.dto.AlbumApiResponse;

import io.reactivex.Single;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface AlbumApi {

    @GET("/2.0/")
    Single<AlbumApiResponse> getAlbumsResponse(@Query("method") String searchMethod,
                                               @Query("album") String albumName);
}
